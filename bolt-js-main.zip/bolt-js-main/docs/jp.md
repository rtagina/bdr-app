---
permalink: ja-jp/concepts
redirect_from:
  - /jp
  - /ja-jp
layout: default
lang: ja-jp
---
