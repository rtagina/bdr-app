# Getting started with TypeScript ⚡️ Bolt for JavaScript
> TypeScript equivalent for Slack app example from 📚 [Getting started with Bolt for JavaScript tutorial][1]

This is a temporary example app intending to show how to work with Bolt's type system. Because the type system is currently lacking, 
this app will change in the future. See [#826][2] for more context.

[1]: https://slack.dev/bolt-js/tutorial/getting-started
[2]: https://github.com/slackapi/bolt-js/issues/826
