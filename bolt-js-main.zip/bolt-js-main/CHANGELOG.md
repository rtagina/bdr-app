# Changelog (legacy)

Version history is now published in the [releases page](https://github.com/slackapi/bolt/releases).

For releases of Slapp before it was renamed to Bolt, see the [v3 Changelog](https://github.com/MissionsAI/slapp/blob/v3/CHANGELOG.md).
